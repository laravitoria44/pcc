"""Gera um ZIP portátil do PetAdote para execução em outro computador."""

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "dist"
OUTPUT_FILE = OUTPUT_DIR / "PetAdote-compartilhamento.zip"
PACKAGE_ROOT = "PetAdote"

IGNORED_DIRS = {
    ".git",
    ".idea",
    ".mypy_cache",
    ".pytest_cache",
    ".venv",
    ".vscode",
    "__pycache__",
    "dist",
    "env",
    "htmlcov",
    "staticfiles",
    "venv",
}
IGNORED_SUFFIXES = {".pyc", ".pyo", ".log"}


def should_include(path: Path) -> bool:
    relative_path = path.relative_to(BASE_DIR)
    return not (
        any(part in IGNORED_DIRS for part in relative_path.parts)
        or path.suffix.lower() in IGNORED_SUFFIXES
    )


def validate_project() -> None:
    required_paths = (
        BASE_DIR / "manage.py",
        BASE_DIR / "requirements.txt",
        BASE_DIR / "db.sqlite3",
        BASE_DIR / "media",
    )
    missing = [path.name for path in required_paths if not path.exists()]
    if missing:
        names = ", ".join(missing)
        raise SystemExit(f"Não foi possível criar o pacote. Ausente: {names}")


def create_package() -> None:
    validate_project()
    OUTPUT_DIR.mkdir(exist_ok=True)

    with ZipFile(OUTPUT_FILE, "w", compression=ZIP_DEFLATED) as archive:
        for path in sorted(BASE_DIR.rglob("*")):
            if path.is_file() and should_include(path):
                relative_path = path.relative_to(BASE_DIR)
                archive.write(path, Path(PACKAGE_ROOT) / relative_path)

    size_mb = OUTPUT_FILE.stat().st_size / (1024 * 1024)
    print(f"Pacote criado em: {OUTPUT_FILE}")
    print(f"Tamanho: {size_mb:.2f} MB")
    print("O banco de dados e os arquivos enviados em media/ foram incluídos.")


if __name__ == "__main__":
    create_package()
