from django.apps import AppConfig


class SaudeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'saude'
    verbose_name = 'Saúde animal'
